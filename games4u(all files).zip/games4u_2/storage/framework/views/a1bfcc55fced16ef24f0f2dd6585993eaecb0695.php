

<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 80px">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Shop</a></li>
                <li class="breadcrumb-item active" aria-current="page">Login</li>
            </ol>
        </nav>
    </div>
    <div class="col-lg-12">
        <div class="col-lg-7">
            <h4>Login</h4>
            <input type="" class="form-control form-control-sm" value=""
                    style="width: 250px; margin-right: 10px;">
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\KHALIESAH\games4u_2\resources\views/login.blade.php ENDPATH**/ ?>