@extends('layouts.app')

@section('content')
    @include('authentication.login')
    

@endsection