@extends('layouts.app')

@section('content')
    @include('authentication.register')
    

@endsection